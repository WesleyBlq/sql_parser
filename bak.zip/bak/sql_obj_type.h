/**
 * (C) 2010-2012 Alibaba Group Holding Limited.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation.
 *
 * Version: $Id$
 *
 * ob_obj_type.h
 *
 * Authors:
 *   zhidong<xielun.szd@alipay.com>
 *
 */

#ifndef SQL_OBJECT_TYPE_H_
#define SQL_OBJECT_TYPE_H_


typedef int64_t    SqlDateTime;
typedef int64_t    SqlPreciseDateTime;
typedef SqlPreciseDateTime SqlModifyTime;
typedef SqlPreciseDateTime SqlCreateTime;

// sql_obj_cast.h
namespace common 
{
    enum SqlObjType
    {
      SqlMinType = -1,

      SqlNullType,   // 空类型
      SqlIntType,
      SqlFloatType,              // @deprecated

      SqlDoubleType,             // @deprecated
      SqlDateTimeType,           // @deprecated
      SqlPreciseDateTimeType,    // =5

      SqlVarcharType,
      SqlSeqType,
      SqlCreateTimeType,

      SqlModifyTimeType,
      SqlExtendType,
      SqlBoolType,

      SqlDecimalType,            // aka numeric
      SqlMaxType,
    };
    
    // print obj type string
    const char* sql_obj_type_str(SqlObjType type);
    // get obj type size for fixed length type
    int64_t sql_obj_type_size(SqlObjType type);
}

#endif //SQL_OBJECT_TYPE_H_
