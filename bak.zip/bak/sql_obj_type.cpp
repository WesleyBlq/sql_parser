/**
 * (C) 2010-2012 Alibaba Group Holding Limited.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation.
 *
 * Version: $Id$
 *
 * ob_obj_type.cpp
 *
 * Authors:
 *   zhidong<xielun.szd@alipay.com>
 *
 */

#include "sql_obj_type.h"

namespace common
{
    const char* sql_obj_type_str(SqlObjType type)
    {
      const char* ret = "unknown_type";
      switch (type)
      {
        case SqlNullType:
          ret = "null";
          break;
        case SqlIntType:
          ret = "int";
          break;
        case SqlFloatType:
          ret = "float";
          break;
        case SqlDoubleType:
          ret = "double";
          break;
        case SqlDateTimeType:
          ret = "datetime";
          break;
        case SqlPreciseDateTimeType:
          ret = "timestamp";
          break;
        case SqlVarcharType:
          ret = "varchar";
          break;
        case SqlSeqType:
          ret = "seq";
          break;
        case SqlCreateTimeType:
          ret = "createtime";
          break;
        case SqlModifyTimeType:
          ret = "modifytime";
          break;
        case SqlExtendType:
          ret = "extend";
          break;
        case SqlBoolType:
          ret = "bool";
          break;
        case SqlDecimalType:
          ret = "decimal";
          break;
        default:
          break;
      }
      return ret;
    }

    int64_t sql_obj_type_size(SqlObjType type)
    {
      int64_t size = 0;
      switch (type)
      {
        case SqlIntType:
          size = sizeof(int64_t);
          break;
        case SqlFloatType:
          size = sizeof(float);
          break;
        case SqlDoubleType:
          size = sizeof(double);
          break;
        case SqlDateTimeType:
          size = sizeof(SqlDateTime);
          break;
        case SqlPreciseDateTimeType:
          size = sizeof(SqlPreciseDateTime);
          break;
        case SqlCreateTimeType:
          size = sizeof(SqlCreateTime);
          break;
        case SqlModifyTimeType:
          size = sizeof(SqlModifyTime);
          break;
        case SqlBoolType:
          size = sizeof(bool);
          break;
        default:
          break;
      }
      return size;
    }
}
